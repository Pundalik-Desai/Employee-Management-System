/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employee.management.system;

// Import necessary libraries for GUI components and event handling
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/**
 *
 * @author Pundalik Desai
 */

/**
 * This is the Splash class for the Employee Management System.
 * It displays a welcome screen with a title and an image.
 */

public class Splash extends JFrame implements ActionListener {

    // Constructor for the Splash class
    Splash() {
        // Set the background color of the content pane to white
        getContentPane().setBackground(Color.WHITE);
        // Set the layout manager to null for absolute positioning
        setLayout(null);

        // Create a label with the title of the application
        JLabel heading = new JLabel("EMPLOYEE MANAGEMENT SYSTEM");
        heading.setBounds(80, 30, 1200, 60); // Set the position and size of the label
        heading.setFont(new Font("serif", Font.PLAIN, 60)); // Set the font style and size
        heading.setForeground(Color.RED); // Set the text color to red
        add(heading); // Add the label to the frame

        // Load an image from the resources
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/front_.jpg"));
        // Scale the image to fit the desired dimensions
        Image i2 = i1.getImage().getScaledInstance(1100, 700, Image.SCALE_DEFAULT);
        // Create a new ImageIcon with the scaled image
        ImageIcon i3 = new ImageIcon(i2);
        // Create a label to display the image
        JLabel image = new JLabel(i3);
        image.setBounds(50, 100, 1050, 500); // Set the position and size of the image label
        add(image); // Add the image label to the frame

        // Create a button for continuing to the next screen
        JButton clickhere = new JButton("CLICK HERE TO CONTINUE");
        clickhere.setBounds(400, 400, 300, 70); // Set the position and size of the button
        clickhere.setBackground(Color.BLACK); // Set the background color of the button to black
        clickhere.setForeground(Color.WHITE); // Set the text color of the button to white
        clickhere.addActionListener(this); // Add an action listener to the button
        image.add(clickhere); // Add the button to the image label

        // Set the size of the frame
        setSize(1170, 650);
        // Set the location of the frame on the screen
        setLocation(200, 80);
        // Make the frame visible
        setVisible(true);
    }

    // This method is called when the button is clicked
    public void actionPerformed(ActionEvent ae) {
        // Hide the splash screen
        setVisible(false);
        // Open the Login screen
        new Login();
    }

    // Main method to run the Splash screen
    public static void main(String args[]) {
        // Create an instance of the Splash class to display the splash screen
        new Splash();
    }
}
